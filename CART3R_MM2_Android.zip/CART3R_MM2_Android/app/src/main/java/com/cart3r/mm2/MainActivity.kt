package com.cart3r.mm2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B0B0F)
private val Panel = Color(0xFF191920)
private val Accent = Color(0xFFE53945)
private val Muted = Color(0xFFAAAAB5)

data class Collectible(val name: String, val quantity: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Cart3rApp() }
    }
}

@Composable
fun Cart3rApp() {
    var items by remember { mutableStateOf(listOf(Collectible("مثال: إكسسوار تجميلي", 1))) }
    var showAdd by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var newQty by remember { mutableStateOf("1") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { showAdd = true },
                    containerColor = Accent,
                    contentColor = Color.White
                ) { Icon(Icons.Default.Add, contentDescription = "إضافة مقتنى") }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("CART3R_MM2", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
                    Text("OWNER • ahmed_xhg", color = Accent, fontWeight = FontWeight.Bold)
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CloudOff, contentDescription = null, tint = Muted)
                                Spacer(Modifier.width(8.dp))
                                Text("الاتصال الرسمي غير مُعدّ بعد", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Text(
                                "هذه نسخة أولية بواجهة محلية. يلزم إعداد خادم آمن ومصادقة Roblox الرسمية قبل تفعيل جلب البيانات عبر الإنترنت.",
                                color = Muted,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
                item { SectionTitle("إدارة المقتنيات") }
                if (items.isEmpty()) {
                    item { Text("لا توجد مقتنيات بعد. استخدم زر الإضافة.", color = Muted) }
                } else {
                    items(items) { collectible ->
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                            Row(
                                Modifier.fillMaxWidth().padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(collectible.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                                    Text("الكمية: ${collectible.quantity}", color = Muted, fontSize = 13.sp)
                                }
                                TextButton(onClick = { items = items - collectible }) {
                                    Text("حذف", color = Accent)
                                }
                            }
                        }
                    }
                }
                item { SectionTitle("CART3R BRAIN") }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                        Text(
                            "المحرك حالياً يعرض تذكيرات تنظيمية فقط. لا ينفّذ أي إجراء تلقائياً، وكل إجراء مستقبلي يتطلب موافقتك.",
                            Modifier.padding(16.dp), color = Muted, fontSize = 13.sp
                        )
                    }
                }
                item { SectionTitle("جدول المهام") }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                        Text(
                            "يمكن إضافة مهام ومدد زمنية في المرحلة التالية. لا توجد مهام مجدولة أو تنبيهات فعالة في هذه النسخة.",
                            Modifier.padding(16.dp), color = Muted, fontSize = 13.sp
                        )
                    }
                }
            }
        }

        if (showAdd) {
            AlertDialog(
                onDismissRequest = { showAdd = false },
                containerColor = Panel,
                title = { Text("إضافة مقتنى", color = Color.White) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("اسم المقتنى") })
                        OutlinedTextField(value = newQty, onValueChange = { newQty = it.filter(Char::isDigit) }, label = { Text("الكمية") })
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val q = newQty.toIntOrNull() ?: 1
                        if (newName.isNotBlank() && q > 0) {
                            items = items + Collectible(newName.trim(), q)
                            newName = ""; newQty = "1"; showAdd = false
                        }
                    }) { Text("إضافة", color = Accent) }
                },
                dismissButton = { TextButton(onClick = { showAdd = false }) { Text("إلغاء") } }
            )
        }
    }
}

@Composable
private fun SectionTitle(value: String) {
    Text(value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
}
